#include <data/rand.h>
#include <map>
#include <set>
#include <vector>
#include <fstream>
#include <iostream>

using namespace std;

vector<int> v;
map<int, int> mp;
vector<int> vv;

int main()
{
	char aa[200];
	ifstream fin("cmdd.in");
	fin >> aa;
	fin.close();
	v.clear();
	mp.clear();
	int n = 100000;
	static const int maxa = 100000;
	static const int maxb = 1;
	static const int lt = 100000;
	ofstream fout(aa);
	fout << n << ' ' << maxa << ' ' << lt << '\n';
	for(int i = 1; i <= maxa; ++i)
		vv.push_back(i);
	for(int i = 1; i <= n; ++i)
	{
//		puts("haha");
//		cout << i << endl;
		int tmp = rand() % vv.size();
		int a = vv[tmp];
		int b = rand(1, maxb);
		fout << a << ' ' << b << '\n';
		mp[a] = b;
		vv.erase(vv.begin() + tmp);
		v.push_back(a);
	}
	int m = 100000;
	fout << m << '\n';
	for(int i = 1, x, y; i < m; ++i)
	{
		int cmd = rand() % 5;
		if(!v.size())
			cmd = 0;
		switch(cmd)
		{
			case 0:
				x = rand(1, maxa);
				fout << "add " << x << '\n';
				if(!mp[x])
					v.push_back(x);
				mp[x]++;
				break;
			case 1:
				x = rand() % v.size();
				mp[v[x]]--;
				fout << "break " << v[x] << '\n';
				if(!mp[v[x]])
					v.erase(v.begin()+x);
				break;
			case 2:
				x = rand() % v.size();
				while(v[x] == maxa)
				{
					if(v.size() == 1)
						goto loop;
					x = rand() % v.size();
				}
				mp[v[x]]--;
				y = rand(1, maxa - v[x] - 1);
				if(!mp[v[x]+y])
					v.push_back(v[x] + y);
				mp[v[x]+y]++;
//				cout << mp[v[x]] << endl;
//				if(v[x] + y > maxa)
//				{
//					cout << v[x] << ' ' << y << ' ' << y + v[x] << endl;
//					puts("haha");
//					return 0;
//				}
				fout << "expansion " << v[x] << ' ' << y << '\n';
				if(!mp[v[x]])
					v.erase(v.begin()+x);
				break;
			case 3:
				x = rand() % v.size();
				mp[v[x]]--;
				if(v[x] == 1)
					goto loop;
				y = rand(1, v[x] - 1);
				if(!mp[v[x]-y])
					v.push_back(v[x] - y);
				mp[v[x]-y]++;
				fout << "cut " << v[x] << ' ' << y << '\n';
				if(!mp[v[x]])
					v.erase(v.begin()+x);
				break;
			default:
loop:
				fout << "query " << rand(1, lt) << '\n';
		}
//		for(int i = 0; i < v.size(); ++i)
//			cout << v[i] << ' ';
//		cout << endl;
	}
	fout << "query " << rand(1, lt) << '\n';
	fout.close();
	return 0;
}
