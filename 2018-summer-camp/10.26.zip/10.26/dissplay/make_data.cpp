#include <cstdlib>
#include <ctime>
#include <cstdio>
#include <fstream>
#include <iostream>

using namespace std;

const char* file = "dissplay%d.in";
const char* otf = "dissplay%d.out";
const char* md = "stdd.exe < %s > %s";

int main()
{
	for(int i = 8; i <= 10; ++i)
	{
		char f[100];
		sprintf(f, file, i);
		ofstream fout("cmdd.in");
		fout << f;
		fout.close();
		system("sj.exe");
		char ot[100];
		sprintf(ot, otf, i);
		char cmd[100];
		sprintf(cmd, md, f, ot);
		system(cmd);
		system("cls");
		cout << "�����ɵ�" << i << "������" << endl;
	}
	system("del cmdd.in");
	return 0;
}
